<?php

namespace App\Actions\Get;

use Lorisleiva\Actions\Concerns\AsAction;

class Breadcrumb
{
    use AsAction;

    public function asController(Request $request)
    {
        return $this->handle($request);
    }
  
    public function handle($request)
    {
        $crumb = [];

        if($request->user) {
            $table = 'users';
            $id = $request->user;
            $row = DB::table($table)->where('id', $id)->first();
        }
        if($request->sensor) {
            $row = DB::table('sensors')
                ->where('sensors.id', $request->sensor)
                ->join('projects','projects.id','=','sensors.project')
                ->join('companies', 'companies.id', '=', 'projects.company')
                ->select('sensors.title', 'projects.title as projectName', 'companies.title as companyName')
                ->first();
            $crumb = [$row->companyName, $row->projectName, $row->title];
        }
        if($request->uplink) {
            $table = 'uplink';
            $id = $request->uplink;
        }
        if($request->measurement) {
            $table = 'measurement';
            $id = $request->measurement;
        }
        if($request->mixCalibration) {
            $table = 'mix_calibration';
            $id = $request->mixCalibration;
        }
        if($request->mix) {
            $table = 'mix';
            $id = $request->mix;
        }
        if($request->navigation) {
            $table = 'navigation';
            $id = $request->navigation;
        }
        if($request->project) {
            $table = 'projects';
            $id = $request->project;
        }
        if($request->gallery) {
            $table = 'galleries';
            $id = $request->gallery;
        }
        if($request->log) {
            $table = 'log';
            $id = $request->log;
        }
        if($request->authority) {
            $table = 'authority';
            $id = $request->authority;
        }
        if($request->company) {
            $table = 'companies';
            $id = $request->company;
        }
        if($request->downlink) {
            $table = 'downlink';
            $id = $request->downlink;
        }
        if($request->auth) {
            $table = 'auth';
            $id = $request->auth;
        }




        return Hermes::send($crumb, 200);
    }
}
